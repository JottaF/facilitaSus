import 'package:flutter/material.dart';

class SplashPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:Container(
        decoration: BoxDecoration(color: Colors.greenAccent),
        child: Center(
        child: Image.asset("assets/images/planeta.png", width: 128, height: 112,))
      )
    );
  }
}