import 'package:app_sus/app_widget.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(AppWidget());
}


