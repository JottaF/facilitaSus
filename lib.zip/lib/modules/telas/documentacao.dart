import 'package:app_sus/modules/home/home_page.dart';
import 'package:flutter/material.dart';

class DocumentacaoPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          Padding(
            padding: EdgeInsets.only(top: 50, left: 45, right: 45, bottom: 30),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children:[
              Image(
                image:AssetImage('images/docImage.png'),
              ),
                SizedBox(
                  height: 30,
                ),
                Text(
              'Documetação necessária para atendimento:',
              style: TextStyle(
                color: Color.fromRGBO(56, 161, 188, 10),
                fontWeight: FontWeight.bold,
                fontSize: 24,
              ),
            ),
            SizedBox(
                  height: 30,
                ),
                 Text(
              'CPF\n\n'
              'RG\n\n'
              'RG\n\n'
              'Cartão do SUS\n\n'
              'Exames caso possua\n\n',
              style: TextStyle(
                color: Color.fromRGBO(56, 161, 188, 10),
                fontSize: 24,
              ),
            ),
            
              ]
            ),
          ),
      
      new Container(
        width: 150.0,
        padding: const EdgeInsets.only(left: 25.0, right:25.0),
        child: TextButton(
                
              style: 
              ButtonStyle(
                //textStyle: MaterialStateProperty.all<TextStyle>(TextStyle(color: Colors.white)),
                backgroundColor: MaterialStateProperty.all<Color>(Color.fromRGBO(89, 179, 235, 1)),
                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(32.0),
                          //side: BorderSide(color: Colors.blue, width:1.0)
                        )
                      )
              ),
              onPressed: (){
                Navigator.push(context,
                MaterialPageRoute(builder: (context) => HomePage()),
                );
              },
              child: const Text(
                'VOLTAR',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 17,
                  ),
                ),
              ),
      ),
                  ],
      ),
    );
  }
}