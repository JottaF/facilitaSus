

import 'package:flutter/material.dart';

class AppBarWidget extends PreferredSize {
  AppBarWidget() 
  : super(
    preferredSize: Size.fromHeight(120), 
    
    child: Container(
      
      height: 120,
      decoration: BoxDecoration(color:Colors.blue),
         child: Padding(
           padding: const EdgeInsets.only(top: 20),

          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: 100),
            
    
            //Column(
            //children: <Widget>[
      //    TextField(
      //       obscureText: false,
      //       maxLines: 1,
      //       decoration: InputDecoration(
      //         border: OutlineInputBorder(
      //           borderRadius: const BorderRadius.all(Radius.circular(40)),
      //         ),
      //         labelText: 'Pesquise aqui',
      //       ),
      //     ),
          
      //   IconButton(
      //     alignment: Alignment.center,
      //     padding: const EdgeInsets.only(),
          
      //     icon: const Icon(Icons.mic),
      //     color: Color.fromRGBO(87, 65, 157, 1),
      //     highlightColor: Color.fromRGBO(230, 233, 239, 1) ,
          
      //     tooltip: 'Pressione para falar',
      //     onPressed: () {}
      //   )
      // ],
      //       )
           ),
        )
    ),
  );
}


